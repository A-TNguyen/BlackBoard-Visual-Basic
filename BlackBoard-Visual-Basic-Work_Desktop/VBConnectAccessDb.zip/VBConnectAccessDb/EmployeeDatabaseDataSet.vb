﻿Partial Class EmployeeDatabaseDataSet
    Partial Public Class Employee_DataDataTable
        Private Sub Employee_DataDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.EmployeeIDColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

        Private Sub Employee_DataDataTable_Employee_DataRowChanging(sender As Object, e As Employee_DataRowChangeEvent) Handles Me.Employee_DataRowChanging

        End Sub

    End Class
End Class
