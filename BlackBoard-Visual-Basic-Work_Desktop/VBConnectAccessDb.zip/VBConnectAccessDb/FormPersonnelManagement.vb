﻿Public Class FormPersonnelManagement
    Private Sub FormPersonnelManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EmployeeDatabaseDataSet.Employee_Data' table. You can move, or remove it, as needed.
        Me.Employee_DataTableAdapter.Fill(Me.EmployeeDatabaseDataSet.Employee_Data)
    End Sub

    Private Sub Employee_DataBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Employee_DataBindingNavigatorSaveItem.Click
        'Save
        'Me.Validate()
        'Me.Employee_DataBindingSource.EndEdit()
        'Me.TableAdapterManager.UpdateAll(Me.EmployeeDatabaseDataSet)
        SaveButton.PerformClick()

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Employee_DataBindingNavigator_RefreshItems(sender As Object, e As EventArgs) Handles Employee_DataBindingNavigator.RefreshItems

    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        AddNewButton.PerformClick()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        'MsgBox("You pressed Delete Button")

        Try

            If MessageBox.Show("Do you want to permanently delete the selected record?",
                               "Delete : Done!", MessageBoxButtons.YesNo,
                               MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) =
                               Windows.Forms.DialogResult.Yes Then
                Employee_DataBindingSource.RemoveCurrent()

                Employee_DataBindingSource.EndEdit()
                Employee_DataTableAdapter.Update(EmployeeDatabaseDataSet.Employee_Data)

                RefreshData()
                MessageBox.Show("The record has been deleted.",
                           "Delete Data : Done!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Return 'Exit Sub

            End If

        Catch ex As Exception
            MessageBox.Show("Delete Data Failed: " & ex.Message.ToString(),
                            "Delete Data : Delete!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click

        'Application.Exit()
        Me.Close()
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
        DeleteButton.PerformClick()
    End Sub

    Private Sub AddNewButton_Click(sender As Object, e As EventArgs) Handles AddNewButton.Click
        'MsgBox("You pressed Save Button")

        Try
            With AddNewButton
                If .Text = "Add New Record" Then
                    Employee_DataBindingSource.AddNew()
                    .Text = "Cancel"
                Else
                    RefreshData()
                    .Text = "Add New Record"
                End If
            End With

            With FirstNameTextBox
                If (.CanSelect) Then
                    .Text = String.Empty
                    .Select()
                End If
            End With

        Catch ex As Exception
            MsgBox("An Error Occured: " & ex.Message.ToString(),
                   MsgBoxStyle.OkOnly Or MsgBoxStyle.Information, "Add new record failed.")
        End Try
    End Sub

    Private Sub RefreshData()
        Try
            Me.Employee_DataBindingSource.Filter = Nothing
            Me.Employee_DataTableAdapter.Fill(Me.EmployeeDatabaseDataSet.Employee_Data)

        Catch ex As Exception
            MsgBox("Refresh Data Error!")
        End Try
    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        'MsgBox("You pressed Add New Button")

        Try

            Dim result As DialogResult
            result = MessageBox.Show("Do you want to save the selected record?", "Save Data : Done!",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If (result = DialogResult.Yes) Then
                Validate()
                Employee_DataBindingSource.EndEdit()
                TableAdapterManager.UpdateAll(Me.EmployeeDatabaseDataSet)

                MessageBox.Show("The record has been save successfully.",
                            "Save Data : Done!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                RefreshData()

                AddNewButton.Text = "Add New Record"

            Else
                'Exit Sub
                Return
            End If

        Catch ex As Exception
            MessageBox.Show("Save | Update Failed: " & ex.Message.ToString(),
                            "Save Data : Done!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    Private Sub CitizenIDLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub EmployeeIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles EmployeeIDTextBox.TextChanged

    End Sub
End Class
